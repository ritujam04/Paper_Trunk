package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Cust_SignUp extends AppCompatActivity {
    Button button2;
    TextView textView,textView2,textView3,textView7;
    EditText editText,editText2,editText3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cust_sign_up);
        button2=findViewById(R.id.button2);
        textView=findViewById(R.id.textView);
        textView2=findViewById(R.id.editText2);
        textView3=findViewById(R.id.textView3);
        textView7=findViewById(R.id.textView7);
        editText=findViewById(R.id.editText);
        editText2=findViewById(R.id.editText2);
        editText3=findViewById(R.id.editText3);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(Cust_SignUp.this, Cust_validation.class);
                startActivity(in);
            }
        });
    }
}