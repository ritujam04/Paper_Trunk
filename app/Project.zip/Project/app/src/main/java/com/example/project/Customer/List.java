package com.example.project.Customer;

public class List {
    private String msg;
    private int image;


    public List(String msg, int image) {
        this.msg = msg;
        this.image = image;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
