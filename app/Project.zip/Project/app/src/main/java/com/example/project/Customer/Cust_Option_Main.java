package com.example.project.Customer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.example.project.R;

import java.util.ArrayList;
import java.util.List;

public class Cust_Option_Main extends AppCompatActivity {
    RecyclerView rv;
    List_Adapter list_adapter;
    List<com.example.project.Customer.List>list;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cust_option_main);
        rv=findViewById(R.id.rv);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        rv.setLayoutManager(linearLayoutManager);
        list=new ArrayList<>();
        list.add(new com.example.project.Customer.List("Peddle the Blank Pages",R.drawable.p1));
        list.add(new com.example.project.Customer.List("Vend the Blank Pages/Books",R.drawable.p3));
        list.add(new com.example.project.Customer.List("Reprocess Blank Pages",R.drawable.p2));
        list.add(new com.example.project.Customer.List("Want used Pages Reusable",R.drawable.p4));
        List_Adapter adapter=new List_Adapter(this,list);
        rv.setHasFixedSize(true);
        rv.setAdapter(adapter);
    }
}