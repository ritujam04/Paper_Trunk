package com.example.project.Customer;

import android.app.Activity;

public class Cust_option_layout extends Activity {
}
