package com.example.project.Customer;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class Cust_Reset extends AppCompatActivity {
TextView textView11;
TextInputLayout layout1, layout2;
TextInputEditText textInputEditText1, textInputEditText2;
Button button7;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cust_reset);
        textView11=findViewById(R.id.textView11);
        layout1=findViewById(R.id.layout1);
        layout2=findViewById(R.id.layout2);
        button7=findViewById(R.id.button7);

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                password_1();
                correct();
            }
        });
    }
            private boolean password_1() {
                String s=layout1.getEditText().getText().toString();
                String val="^"+
                        "(?=.*[a-zA-Z])"+
                        "(?=.*[@#$%^&*])"+
                        "(?=\\S+$)"+
                        ".{4,}"+
                        "$";
                if (s.isEmpty())
                {
                    layout1.setError("Need to be Filled!!");
                    return false;
                } else if (!s.matches(val)) {
                    layout1.setError("Password is too weak!!");
                    return false;
                }else{
                    layout1.setError(null);
                    layout1.setErrorEnabled(false);
                    return false;
                }
            }
             private void correct() {
                String l1=layout1.getEditText().getText().toString();
                String l2=layout2.getEditText().getText().toString();
                if(l1.equals(l2)){
                    Toast.makeText(Cust_Reset.this, "Password is Set", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Cust_Reset.this, "Password doesn't Matched", Toast.LENGTH_SHORT).show();
                }
             }
}