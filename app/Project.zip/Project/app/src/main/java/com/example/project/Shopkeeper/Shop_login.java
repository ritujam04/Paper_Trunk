package com.example.project.Shopkeeper;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.project.R;

public class Shop_login extends AppCompatActivity {
    Button button8;
    TextView textView14,textView16;
    EditText editTextText,editTextText2;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_login);
        button8=findViewById(R.id.button8);
        textView14=findViewById(R.id.textView14);
        textView16=findViewById(R.id.textView16);
        editTextText=findViewById(R.id.editText);
        editTextText2=findViewById(R.id.editText2);

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(Shop_login.this, Shop_List.class);
                startActivity(in);
            }
        });
        textView16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(Shop_login.this, Shop_SignUp.class);
                startActivity(in);
            }
        });
        textView14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Shop_login.this, Shop_forgot_pass.class);
                startActivity(i);
            }
        });
    }
}