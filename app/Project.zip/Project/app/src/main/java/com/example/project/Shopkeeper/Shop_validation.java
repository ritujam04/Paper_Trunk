package com.example.project.Shopkeeper;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.project.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class Shop_validation extends AppCompatActivity {
TextView textView24;
TextInputLayout layout_1, layout_2;
TextInputEditText password_1, username_1;
Button button13;

@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_validation);
        textView24=findViewById(R.id.textView24);
        layout_1=findViewById(R.id.layout_1);
        layout_2=findViewById(R.id.layout_2);
        password_1=findViewById(R.id.password_1);
        username_1=findViewById(R.id.username_1);
        button13=findViewById(R.id.button13);

        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username1();
                password1();
            }
        });
}
            private boolean username1() {
                String s=layout_1.getEditText().getText().toString();
                String ows="\\A\\w{4,20}\\z";
                if (s.isEmpty()){
                    layout_1.setError("Needs to be filled!!");
                    return false;
                } else if (s.length()>10) {
                    layout_1.setError("Username too Long!!");
                    return false;
                } else if (!s.matches(ows)) {
                    layout_1.setError("Spaces are not filled!!!");
                    return false;
                } else {
                    layout_1.setError(null);
                    layout_1.setErrorEnabled(false);
                    return true;
                }
            }
             private boolean password1() {
                 String s=layout_2.getEditText().getText().toString();
                 String val="^"+
                         "(?=.*[a-zA-Z])"+
                         "(?=.*[@#$%^&*])"+
                         "(?=\\S+$)"+
                         ".{4,}"+
                         "$";
                 if (s.isEmpty())
                 {
                     layout_2.setError("Need to be Filled!!");
                     return false;
                 } else if (!s.matches(val)) {
                     layout_2.setError("Password is too weak!!");
                     return false;
                 }else{
                     layout_2.setError(null);
                     layout_2.setErrorEnabled(false);
                     return false;
                 }
            }
}