package com.example.project.Customer;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.project.R;

public class Cust_Option_Main2 extends AppCompatActivity {
    ImageView imageView3;
    TextView textView28,textView29;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cust_option_main2);
        imageView3=findViewById(R.id.imageView3);
        textView28=findViewById(R.id.textView28);
        textView29=findViewById(R.id.textView29);

        imageView3.setImageResource(getIntent().getIntExtra("iv",0));
        textView28.setText(getIntent().getStringExtra("textView9"));
    }
}