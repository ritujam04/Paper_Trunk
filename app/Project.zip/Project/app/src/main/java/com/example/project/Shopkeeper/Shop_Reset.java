package com.example.project.Shopkeeper;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.R;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class Shop_Reset extends AppCompatActivity {
TextView textView21;
TextInputLayout layout, layout_1;
TextInputEditText textInputEditText, textInputEditText_1;
Button button10;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_reset);
        textView21=findViewById(R.id.textView21);
        layout=findViewById(R.id.layout);
        layout_1=findViewById(R.id.layout_1);
        textInputEditText=findViewById(R.id.textInputEditText);
        textInputEditText_1=findViewById(R.id.textInputEditText_1);
        button10=findViewById(R.id.button10);

        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                password1();
                correct();
            }
        });
    }
    private boolean password1() {
        String s=layout.getEditText().getText().toString();
        String val="^"+
                "(?=.*[a-zA-Z])"+
                "(?=.*[@#$%^&*])"+
                "(?=\\S+$)"+
                ".{4,}"+
                "$";
        if (s.isEmpty())
        {
            layout.setError("Need to be Filled!!");
            return false;
        } else if (!s.matches(val)) {
            layout.setError("Password is too weak!!");
            return false;
        }else{
            layout.setError(null);
            layout.setErrorEnabled(false);
            return false;
        }
    }
    private void correct() {
        String l1=layout.getEditText().getText().toString();
        String l2=layout_1.getEditText().getText().toString();
        if(l1.equals(l2)){
            Toast.makeText(Shop_Reset.this, "Password is Set", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(Shop_Reset.this, "Password doesn't Matched", Toast.LENGTH_SHORT).show();
        }
    }
}