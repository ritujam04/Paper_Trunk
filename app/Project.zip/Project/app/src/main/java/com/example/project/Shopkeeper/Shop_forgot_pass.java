package com.example.project.Shopkeeper;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.project.R;

public class Shop_forgot_pass extends AppCompatActivity {
TextView textView22;
EditText editText6;
Button button11;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_forgot_pass);
        textView22=findViewById(R.id.textView22);
        editText6=findViewById(R.id.editText6);
        button11=findViewById(R.id.button11);
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Shop_forgot_pass.this, Shop_Reset.class);
                startActivity(intent);
            }
        });
    }
}